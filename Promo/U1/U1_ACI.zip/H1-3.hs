
flaecheninhalt :: Double -> Double -> Double
flaecheninhalt a b = pi*a*b

exzentrizitaet :: Double -> Double -> Double
exzentrizitaet a b = sqrt a^2-b^2

umfang :: Double -> Double -> Double
umfang a b = pi*(3/2*(a+b)-sqrt a*b)
