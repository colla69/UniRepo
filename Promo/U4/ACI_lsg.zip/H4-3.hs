

data MyList a = Leer | Element a (MyList a)
 deriving Show 


verketten :: MyList a -> MyList a -> MyList a
verketten Leer Leer                     = Leer
verketten Leer  (Element a(b))        = (Element a( b ))
verketten (Element a(b)) Leer         = (Element a( b ))
verketten (Element a(b)) (Element x(y)) = (Element a (verketten b (Element x(y))))
