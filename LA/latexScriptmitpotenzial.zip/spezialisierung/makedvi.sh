#!/bin/sh

## Hier liegen die .dtx-Dateien
packagesourcedir="../dtx-test"
## Hier liegen die .sty- und .cls-Dateien.
packageinstalldir='/cygdrive/l/localtexmf/tex/latex/paul'

if [ "$1" == "-help" ]
then
echo "makedvi  -  Erstellt eine DVI-Datei aus einem LaTeX-Quelltext,
            inklusive Index.
Nutzung:
   makedvi -clean
   makedvi -help
   makedvi [<dokument>]

Zun�chst wird �berpr�ft, ob alle Packages aktuell sind, andernfalls
diese neu erstellt (mittels '${packagesourcedir}/makepackage', der
Verzeichnisname sowie die Packages sind im Skript einstellbar).
Danach wird mehrfach LaTeX sowie einmal makeindex mit passenden
Parametern aufgerufen.
Am Ende wird ein DVI-Previewer aufgerufen.
Sollte es dabei zu einem Fehler kommen, wird abgebrochen.

Optionen:
   -clean   l�scht �berbleibsel des Dokumentationserstellens, so dass nur die
             Quelltexte und das Ergebnis �brigbleiben.
   -help    zeigt diese Hilfe an.
Parameter:
 <dokument>  der Name des Dokumentes (ohne die Endung .tex).
             Falls weggelassen, wird 'spezialisierung' genommen."
  exit
fi

if [ "$1" == "-clean" ]
then
  (
   shopt -s nullglob
   echo "Aufr�umen ..."
   echo "wird gleich gel�cht" > cleanup.dummy
   rm cleanup.dummy *.aux *.glo *.gls *.ind *.idx *.ilg *.log *.toc *.filelist
  )
  exit
fi


if [ -n "$1" ]
then
	packagename="$1"
else
	packagename="spezialisierung"
fi

echo Wir erzeugen die DVI-Datei f�r ${packagename}

 ## erstellt, falls notwendig (d.h. Quelltext neuer als Package),
 ## eine Package-Datei neu (und auch gleich die Doku).
function makeIfNecessary()
{
	if [ "${packagesourcedir}/$1.dtx" -nt "${packageinstalldir}/$1.$2" ]
	then
		pushd ${packagesourcedir}
		./makepackage.sh $1
		RES=$?
		popd
		return $RES
	fi
}

## Alle notwendigen Packages neubauen, falls ge�ndert
makeIfNecessary robustcommand sty &&
makeIfNecessary alg-script cls &&
makeIfNecessary extpfeil sty &&
makeIfNecessary randbild sty &&
makeIfNecessary faktor sty &&
makeIfNecessary underline sty &&
makeIfNecessary dateiliste sty &&
makeIfNecessary specdefs sty &&

## Erste Version des Dokumentes erzeugen
latex "${packagename}.tex" &&

## Jetzt machen wir davon eine Kopie, und rufen diese mit
## YAP auf. So kann man sich schon mal ansehen, was rauskommen
## wird, ohne dass die n�chsten X L�ufe abgewartet werden m�ssen.

mv "${packagename}.dvi" "${packagename}-kopie.dvi" &&
start yap -1 "${packagename}-kopie.dvi" &&

## Nochmal (mit Inhaltsverzeichnis)
latex "${packagename}.tex" &&

## Glossar erzeugen
if [ -e "${packagename}.glo" ]
then
  makeindex -s "${packagename}.ist" -t "${packagename}.glg" -o "${packagename}.gls" "${packagename}.glo" 
fi &&

## Nochmal (mit Glossar)
latex "${packagename}.tex" &&


## Index erzeugen
if [ -e "${packagename}.idx" ]
then
  makeindex ${packagename}
fi &&


## Dokument neu setzen (mit Index)
latex "${packagename}.tex" &&

## Noch einmal alle Querverweise (z.B. Inhaltsverzeichnis) anpassen.
latex  "${packagename}.tex" &&

## Previewer aufrufen
mv "${packagename}.dvi" "${packagename}-kopie.dvi" &&
start yap -1 "${packagename}-kopie.dvi" &&

echo "Fertig (ohne Fehler)."
