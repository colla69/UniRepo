#!/bin/sh

if [ "$1" == "-help" ]
then
echo 'makepackage  -  installiert ein LaTeX-Package und erstellt die
                Dokumentation als .dvi
Nutzung:
   makepackage -clean
   makepackage -help
   makepackage [<dtxname>]

Es wird das Package installiert (d.h. aus der .dtx-Datei eine .sty- oder
.cls-Datei erstellt, und diese in das vorhergesehene Verzeichnis gesteckt),
sofern eine Datei <dtxname>.ins  gefunden wird.
Danach wird die Dokumentation erstellt, mittels mehrfacher Durchl�ufe von
LaTeX, zwischendurch auch makeindex, um einen Index bzw. eine �nderungsliste
zu erstellen.
Sollte es dabei zu einem Fehler kommen, wird abgebrochen.

Optionen:
   -clean   l�scht �berbleibsel des Dokumentationserstellens, so dass nur die
             Quelltexte und das Ergebnis �brigbleiben.
   -help    zeigt diese Hilfe an.
Parameter:
 <dtxname>  der Name des Packages (ohne die Endung .dtx).
             Falls weggelassen, wird "alg-script" genommen.'
  exit
fi

if [ "$1" == "-clean" ]
then
  (
   shopt -s nullglob
   echo "Aufr�umen ..."
   echo "wird gleich gel�cht" > cleanup.dummy
   rm cleanup.dummy *.aux *.glo *.gls *.ind *.idx *.ilg *.log *.toc
  )
  exit
fi

if [ -n "$1" ]
then
	packagename="$1"
else
	packagename="alg-script"
fi

echo Wir erzeugen Doku und Package f�r "${packagename}".


## .sty erzeugen
if [ -e ${packagename}.ins ]
then
  latex ${packagename}.ins
fi &&
## Erste Version der Doku erzeugen
latex "${packagename}.dtx" &&
## Versionsliste und Index erzeugen
if [ -e "${packagename}.glo" ]
then
makeindex -g -s gglo.ist -o "${packagename}.gls" "${packagename}.glo"
fi &&
if [ -e "${packagename}.idx" ]
then
	makeindex -s gind.ist -o "${packagename}.ind" "${packagename}.idx" 
fi &&
## Doku neu setzen (mit Index)
latex "${packagename}.dtx" &&
## Noch einmal alle Querverweise anpassen.
latex  "${packagename}.dtx" &&
## Previewer aufrufen
start yap -1 "${packagename}.dvi"
