import java.util.Arrays;

public class MinimumString {
	
	private String[] array;
	
	public MinimumString(String[] array){
		this.array = array;
	}
	
	public String getMinimum(){
		Arrays.sort(array);
		return array[0];
	}
	
	public static void main(String[] args){
		String[] stringarray = {"ist", "das", "ein", "test"};
		MinimumString test = new MinimumString(stringarray);
		System.out.println("Minimum: " + test.getMinimum());		
	}
	
}
