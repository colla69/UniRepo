import java.util.Arrays;

public class MinimumInt {
	
	private int[] array;
	
	public MinimumInt(int[] array){
		this.array = array;
	}
	
	public int getMinimum(){
		Arrays.sort(array);
		return array[0];
	}
		
	public static void main(String[] args){
		int[] intarray = {5, 2, 3, 4};
		int[] intarray2 = {14, 67, 8, 30};
		MinimumInt test = new MinimumInt(intarray2);
		System.out.println(test.getMinimum());
		
	}
	
}