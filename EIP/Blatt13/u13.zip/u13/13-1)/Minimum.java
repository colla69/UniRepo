import java.util.Arrays;

public class Minimum<T> {
	
	private T[] array;
	
	public Minimum(T[] array){
		this.array = array;
	}
	
	public T getMinimum(){
		try{					//if(array[0] instanceof Comparable)    reicht nicht
			Arrays.sort(array);
			return array[0];
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			return null;
		}
	}
		
	public static void main(String[] args){
		Integer[] intarray = {5, 2, 3, 4};
		String[] stringarray = {"ist", "das", "ein", "test"};
		Object[] objectarray = {new Integer(1), "hallo"};
		Integer[][] arrays = {{1,2,3},{1,3,5}};
		
		Minimum test = new Minimum(arrays);
		System.out.println(test.getMinimum());
		
	}
	
}
