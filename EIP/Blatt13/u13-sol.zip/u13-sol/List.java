public class List<T> {
	private int size;
	private Entry<T> head;
	
	public List() {
		this.size = 0;
		this.head = null;
	}
	
	public int size() {
		return this.size;
	}
	
	public int sizeDyn() {
		int size = 0;
		if(this.head != null){		
			Entry<T> entry = this.head;
			while(entry != null){
				size++;
				entry = entry.getNext();
			}
		}
		return size;
	}
	
	public void prefix(Entry<T> newHead) {
		newHead.setNext(this.head);
		this.head = newHead;
		this.size++;
	}
	
	public void prefix(T element) {
		this.prefix(new Entry(element));
	}
	
	// TODO
	public void postfix(Entry<T> newLast) {
		this.size++;
		if(this.head == null)
			this.head = newLast;
		else if(this.head.getNext() == null)
			this.head.setNext(newLast);
		else 
			this.rest().postfix(newLast);
	}

	public void postfix(T element) {
		this.postfix(new Entry(element));
	}
	
	public T first() {
		if(this.head == null)
			return null;
		return this.head.getElement();
	}
	
	// TODO
	public T last() {
		if(this.head == null)
			return null;
		if(this.head.getNext() == null)
			return this.head.getElement();
		return this.rest().last();
	}
	
	public List<T> rest() {
		if(this.head == null)
			return null;
		List<T> erg = new List<T>();
		erg.size = this.size - 1;
		erg.head = this.head.getNext();
		return erg;
	}
	
	public T proj(int index){
		if(this.head == null) {
			return null;
		}
		if(index >= this.size())
			return null;
		if(index == 1)
			return this.head.getElement();
		else
			return this.rest().proj(index - 1);
	}
	
	public boolean isEmpty() {
		return this.head == null;
	}
	
	public void concat(List<T> list){
		this.size += list.size;
		this.postfix(list.head);
	}
	
	// TODO 
	public List<T> clone(){
		List<T> erg = new List<T>();
		if(this.isEmpty())
			return erg;
		erg.size = this.size();
		Entry<T> readEntry = this.head;
		Entry<T> writeEntry = new Entry<T>(readEntry.getElement());
		erg.prefix(writeEntry);
		while(readEntry.getNext() != null){
			readEntry = readEntry.getNext();
			writeEntry.setNext(new Entry<T>(readEntry.getElement()));
			writeEntry = writeEntry.getNext();	
		}
		return erg;
	}
	
	// TODO
	public List<T> concatClone(List<T> list){
		List<T> erg = this.clone();
		List<T> erg2 = list.clone();
		
		// Alternativ:
		// erg.concat(erg2);
		// return erg;
		Entry<T> entry = erg.head;
		while(entry.getNext() != null){
			entry = entry.getNext();
		}
		entry.setNext(erg2.head);
		erg.size += erg2.size();
		return erg;
	}
	
	// TODO 
	public List<T> reverse() {
		List<T> erg = new List<T>();
		if(this.isEmpty())
			return erg;
		erg.size = this.size();
		
		Entry<T> entry = this.head;
		while(entry != null){
			erg.prefix(entry.getElement());
			entry = entry.getNext();
		}
		return erg;
	}
	
	// TODO
	public void removeDuplicates() {
		if(this.isEmpty())
			return;
		Entry<T> entry = this.head;
		while(entry != null){
			T element = entry.getElement();
			Entry<T> entryInner = entry;
			while(entryInner.getNext() != null){
				T element2 = entryInner.getNext().getElement();
				if(element.equals(element2)){
					entryInner.setNext(entryInner.getNext().getNext());
				}
				entryInner = entryInner.getNext();
			}
			entry = entry.getNext();
		}
	}
	
	public String toString(){
		if(isEmpty())
			return "()";
		String str = "(";
		Entry<T> entry = head;
		while(entry != null) {
			str += entry.getElement();
			entry = entry.getNext();
			if(entry != null)
				str += ", ";
		}
		str += ")";
		return str;
	}
	
	
}