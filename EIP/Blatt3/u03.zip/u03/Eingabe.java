import java.util.Scanner;

public class Eingabe {
	public static void main(String[] args) {
		
		System.out.print("Hello World!");
		
		Scanner sc = new Scanner(System.in);
		int alter = sc.nextInt();
		
		// TODO: Ausgabe des Alters
		
		// Wenn das Alter groe�er oder gleich 16 ist, dann gebe Bier aus. 
		// Sonst gebe kein Bier aus. 
		if (true) { //TODO: Bedingung formulieren
			//TODO: Ausgabe A
			}
		else {
			//TODO: Ausgabe B
			}
		}
	
}