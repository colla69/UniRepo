public class HelloWorld {
  public static void main(String[] args) {
    // Einfach einen kleinen Text ausgeben
    System.out.println("Hallo, Welt!");
  }
}
