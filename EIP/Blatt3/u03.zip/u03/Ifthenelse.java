if(Bedingung) {
	//Wenn Bedingung erfuellt ist, dann tue alles in diesem Block.
}
else {
	//Wenn Bedingung nicht erfuellt ist, dann tue dies hier.
}
	