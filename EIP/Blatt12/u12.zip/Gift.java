package DBS;

public interface Gift {

}
