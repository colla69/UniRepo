package DBS;

public class Ork extends Einheit implements Krieger, SchwereRuestung{
	
	public String toString() {
		return "Ork" + super.toString();
	}
	
	public boolean kannAngreifen(Einheit ziel) {
		return ziel instanceof Mensch || ziel instanceof Zwerg || ziel instanceof Schaf;
	}
}
