package DBS;

public class SchafException extends Exception {

	public SchafException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
