package DBS;

public class Schaf extends Einheit{

	void werdeAngegriffen(int schaden) throws SchafException{
		super.werdeAngegriffen(schaden);
		if(this.lebtNoch())
			throw new SchafException("Ein Schaf versucht zu fliehen!");
		else
			throw new SchafException("Ein Schaf fiel den Horden zum Opfer!");
	}
	
	public String toString() {
		return "Schaf" + super.toString();
	}
}
