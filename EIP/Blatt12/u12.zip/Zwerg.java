package DBS;

public class Zwerg extends Einheit implements Krieger, Fernkampf, SchwereRuestung{

	public String toString() {
		return "Zwerg" + super.toString();
	}
	
	public boolean kannAngreifen(Einheit ziel) {
		return ziel instanceof Ork || ziel instanceof Goblin || ziel instanceof Schaf;
	}
	
}
