package DBS;

public interface Krieger {

	//public boolean attackiere(Einheit ziel);
	public boolean kannAngreifen(Einheit ziel);
}
