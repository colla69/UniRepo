package DBS;

public interface Fernkampf {

}
