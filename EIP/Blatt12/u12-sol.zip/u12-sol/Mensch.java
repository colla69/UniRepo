package DBS;

public class Mensch extends Einheit implements Krieger, Fernkampf, SchwereRuestung{

	public String toString() {
		return "Mensch" + super.toString();
	}
	
	public boolean kannAngreifen(Einheit ziel) {
		return ziel instanceof Ork || ziel instanceof Goblin || ziel instanceof Schaf;
	}
}
