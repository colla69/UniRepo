public class Quartett {
	private Musiker[] besetzung = new Musiker[4];
	
	public static void main(String[] args) {
		Quartett q = new Quartett();
		q.engagiere("Heinz");
		q.engagiere("Gustav");
		q.engagiere("Balduin");
		q.engagiere("Nepumuk");
		q.engagiere("Ralf");
	}
	
	private void engagiere(String name) {
		try {
			Musiker m = Musiker.erstelleMusiker(name);
			System.out.println(m + " spielt nun im Quartett!");
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}

class QuartettVollException extends Exception {

	public QuartettVollException(){
		super("Das Quartett ist voll und kann keine neuen Musiker aufnehmen!");
	}
}

public class Musiker {
	private static final int max = 4;
	private static int anzahl = 0;
	private String name = "";
	
	private Musiker(String name){
		this.name = name;
	}
	
	public static Musiker erstelleMusiker(String name) throws Exception{
		if(anzahl < max) {
			anzahl++;
			Musiker m = new Musiker(name);
			return m;
		}
		else {
			throw new QuartettVollException();
		}
	}
	
	public String toString() {
		return name;
	}
}