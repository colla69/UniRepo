package DBS;

public class Goblin extends Einheit implements Krieger, Fernkampf, Gift{
		
	public String toString() {
		return "Goblin" + super.toString();
	}
	
	public boolean kannAngreifen(Einheit ziel) {
		return ziel instanceof Mensch || ziel instanceof Zwerg || ziel instanceof Schaf;
	}
}
