package DBS;

public interface SchwereRuestung {

}
