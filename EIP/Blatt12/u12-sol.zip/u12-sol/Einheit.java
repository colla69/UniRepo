package DBS;
import java.util.Random;

public abstract class Einheit implements Comparable<Einheit>{

	private int lebenspunkte = 20;
	
	private static Random random = new Random();
	
	private int initiative = Einheit.random.nextInt(100);
	
	
	
	boolean kannAngreifen(Einheit ziel) {
		return false;
	}
	
	void werdeAngegriffen(int schaden) throws SchafException {
		this.lebenspunkte -= schaden;
	}
	
	public boolean lebtNoch() {
		return lebenspunkte > 0;
	}
	
	
	
	boolean attackiere(Einheit ziel){
		if(kannAngreifen(ziel)) {
			int schaden = 2;
			if(this instanceof Fernkampf)
				schaden += 2;
			if(ziel instanceof SchwereRuestung)
				schaden /= 2;
			if(this instanceof Gift)
				schaden += 2;
			
			try{
				System.out.println(this + " greift " + ziel + " an.");
				ziel.werdeAngegriffen(schaden);
			} catch(SchafException e) {
				System.out.println(e.getMessage());
				return false;
			}
			return true;

		}

		return false;
	}
	
	public String toString() {
		return "(" + initiative + ", " + lebenspunkte + ")";
	}
	
	public int compareTo(Einheit andereEinheit){
        // compareTo should return < 0 if this is supposed to be
        // less than other, > 0 if this is supposed to be greater than 
        // other and 0 if they are supposed to be equal
		return andereEinheit.initiative() - this.initiative;
    }
	
	public int initiative() {
		return this.initiative;
	}
	
}
